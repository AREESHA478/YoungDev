import React from 'react';

function Services() {
  return <h2>Service Page</h2>;
}

export default Services;