// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';  // Import Routes
import './App.css';


import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Services from './Services';
import Navigation from './Navigation';

function App() {
  return (
    <Router>
      <div>
        <Navigation />
        <Routes>  {/* Use Routes instead of Switch */}
          <Route path="/home" element={<Home />} />  {/* Use element and pass JSX component */}
          <Route path="/about" element={<About />} />  {/* Use element and pass JSX component */}
          <Route path="/services" element={<Services />} />  {/* Use element and pass JSX component */}
          <Route path="/contact" element={<Contact/>} />  {/* Use element and pass JSX component */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
